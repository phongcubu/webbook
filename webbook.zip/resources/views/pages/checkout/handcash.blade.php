
@extends('welcome')
@section('content')
<section id="cart_items" class="cart_items">
    <div class="container" >
        <div class="review-payment">
            <h2>cảm ơn bạn đã đặt hàng ở chỗ chúng tôi, chúng tôi sẽ liên hệ với bạn sớm nhất </h2>
        </div>
        

  
       

    </div>
</section> <!--/#cart_items-->
@endsection