@extends('admin_layout')
@section('admin_content')

<section class="wrapper">
	<h3> HẾ NÔ CÁC BẠN LẠI LÀ MÌNH Đây</h3>
    </section>
@endsection